<template>
  <div class="suggest-detail-page">
    <GlobalMain title="자율게시판" />
    <StatusBar :status="suggest.pro_state" />
    <FreeboardDetail :suggest="suggest" />
    <FreeboardComments />
  </div>
</template>

<script>
import { mapActions, mapState } from 'vuex'
import GlobalMain from '~/components/shared/GlobalMain'
import StatusBar from '~/components/shared/StatusBar'
import FreeboardDetail from '~/components/FreeboardDetail'
import FreeboardComments from '~/components/FreeboardComments'

export default {
  components: {
    GlobalMain,
    StatusBar,
    FreeboardDetail,
    FreeboardComments
  },
  data () {
    return {
    }
  },
  computed: {
    ...mapState({
      userInfo: state => state.userInfo,
      suggest: state => state.suggestDetail
    })
  },
  async created () {
    try {
      const { query: { idx, type } } = this.$route
      const isChildrenType = type === 'children'
      await this.GET_SUGGEST_DETAIL({ idx, isChildrenType })
    } catch (e) {
      console.error(e)
    }
  },
  methods: {
    ...mapActions([
      'GET_SUGGEST_DETAIL'
    ])
  }
}
</script>

<style>

</style>
